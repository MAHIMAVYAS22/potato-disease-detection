package com.example.potato_disease_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
